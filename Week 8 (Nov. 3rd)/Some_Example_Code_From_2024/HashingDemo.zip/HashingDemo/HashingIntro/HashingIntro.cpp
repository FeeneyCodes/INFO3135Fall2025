/*
Janice Manning
October, 2024

Examples of hash functions used to calculate hash values
*/

#include <iostream>
#include <string>

using namespace std;

int hash_bad(const string& key)
{
	int hash = 0;
	for (const char& ch : key)
		hash += ch;
	return hash;
}

int hash_better(const string& key)
{
	int hash = 0;
	int counter = 1;

	for (const char& ch : key)
		hash += ch * counter++;		//adds more complexity, differentiation to the hash return
	return hash;	
}

//The DJB2 algorithm is a popular hash function for strings
//it bitwise operations and multiples the hash value by 33 
//Named for Daniel J. Bernstein who discovered the 5381 produces good distribution

int hash_best(const string& key)
{
	int hash = 5381;
	for (const char& ch : key)
	{
		hash = ((hash << 5) + hash) + ch;
	}
	return hash;
}


int main()
{
	//1. demonstrate a collision
	string key1 = "tab";
	string key2 = "bat";
	cout << "Hash = " << hash_bad(key1) << endl;
	cout << "Hash = " << hash_bad(key2) << endl;
	cout << endl;

	cout << "Hash = " << hash_better(key1) << endl;
	cout << "Hash = " << hash_better(key2) << endl;
	cout << endl;

	cout << "Hash = " << hash_best(key1) << endl;
	cout << "Hash = " << hash_best(key2) << endl;
	cout << endl;

}