#pragma once
/*
Janice Manning
October, 2024

A HashTable class implementation
Uses chaining for collision handling
*/

#include <iostream>
#include <string>
#include <vector>
#include <list>

using namespace std;

class HashTable
{
private:
	vector<list<int>> table;
	int tableSize;

public:
	HashTable(int size) : tableSize(size)
	{
		table.resize(size);	//represents an empty talbe
	}

	int divisionMethod(int key)
	{
		return key % tableSize;
	}

	//use extraction mehtod by extracting the middle digits to find has
	int extractionMethod(int key)
	{
		//just mod by size if too few digits
		if (key < 100)
			return key % tableSize;

		//otherwise, extract middle digits
		//get rid of last digit, extract next two digits
		int middleDigits = (key / 10) % 100;

		return middleDigits % tableSize;
	}

	int radixMethod(int key, int base)
	{
		string result;

		//work with absolute value (in cases of negatives)
		//divide base and collect remainders
		while (abs(key) > 0)
		{
			int remainder = key % base;
			result += to_string(remainder);
			key /= base;
		}

		//reverse the string to get the correct order of digits
		reverse(result.begin(), result.end());

		//gets last char and converts its digits
		int lastDigit = result.back() - '0';

		return lastDigit % tableSize;
	}

	void insert(int key)
	{
		//int hashValue = divisionMethod(key);
		//int hashValue = extractionMethod(key);
		int hashValue = radixMethod(key, 7);

		//collision handling using chaining 
		//insert the key in the correct bucket
		//note that in the event of a collision, the key is added to the list at the currect index
		table[hashValue].push_back(key);
	}

	int retrieve(int key)
	{
		//int hashValue = divisionMethod(key);
		//int hashValue = extractionMethod(key);
		int hashValue = radixMethod(key, 7);

		for (int element : table[hashValue])
		{
			if (element == key)
				return hashValue;
		}
		
		return -1;
	}


	void print()
	{
		cout << "Hash Table:\n";
		for (int i = 0; i < tableSize; ++i)
		{
			cout << "Index " << i << ": ";
			for (int x : table[i])
				cout << x << " ";
			cout << endl;				
		}
	}

};
