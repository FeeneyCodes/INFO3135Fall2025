/*
Janice Manning
October, 2024

Demonstrates the use of the HashTable class to store integer data (keys)
for insertion with an attempt to avoid collisions
*/

#include "HashTable.hpp"

using namespace std;

int main()
{
	HashTable table(11);

	//print the table
	table.print();
	cout << endl;

	//integers to be hashed and added to the hash table
	//int keys[] = { 34,45,3,87,65,32,1,12,17 };
	int keys[] = { 314,465,3777,807,625,3552,781,192,17 };

	//insert integers into the table
	for (int key : keys)
		table.insert(key);

	//print the table
	table.print();
	cout << endl;

	//try to retrieve a value
	int key = 45;
	int index = table.retrieve(key);

	if (table.retrieve(key) != -1)
	{
		cout << "Key " << key << " is found at " << index << endl;
	}
	else
	{
		cout << "Key " << key << " is not found at" <<  endl;
	}

}