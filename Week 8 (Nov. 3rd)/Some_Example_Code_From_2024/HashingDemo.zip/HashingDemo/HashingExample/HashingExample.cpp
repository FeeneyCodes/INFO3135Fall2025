/*
Janice Manning
October, 2024

Examples of hash functions used to calculate hash values using division 
Store and retrieval of keys in a table give their hash value
*/

#include <iostream>
#include <string>
#include <vector>

using namespace std;

size_t simpleHash(const string& key, size_t size)
{
	size_t hash = 0;
	for (const char& ch : key)
		hash = hash * 31 + ch;
	return hash % size;
}


int main()
{
	//create a fixed-size container
	vector<string> table(11);

	//1. store names into the table using hashing
	string key = "apple";
	size_t index = simpleHash(key, table.size());
	table[index] = key;
	cout << "Store \"" << key << "\" at index " << index << endl;

	key = "orange";
	index = simpleHash(key, table.size());
	table[index] = key;
	cout << "Store \"" << key << "\" at index " << index << endl;

	key = "kiwi";
	index = simpleHash(key, table.size());
	table[index] = key;
	cout << "Store \"" << key << "\" at index " << index << endl;

	key = "banana";
	index = simpleHash(key, table.size());
	table[index] = key;
	cout << "Store \"" << key << "\" at index " << index << endl;

	key = "grape";
	index = simpleHash(key, table.size());
	table[index] = key;
	cout << "Store \"" << key << "\" at index " << index << endl;

	key = "pear";
	index = simpleHash(key, table.size());
	table[index] = key;
	cout << "Store \"" << key << "\" at index " << index << endl;


	key = "watermelon";
	index = simpleHash(key, table.size());
	table[index] = key;
	cout << "Store \"" << key << "\" at index " << index << endl;

	key = "strawberry";
	index = simpleHash(key, table.size());
	table[index] = key;
	cout << "Store \"" << key << "\" at index " << index << endl;

	//print the table
	cout << endl << "Hash Table:" << endl;
	for (size_t i = 0; i < table.size(); ++i)
	{
		cout << "Index = " << i << ": ";
		if (table[i] != "")
			cout << table[i];
		else
			cout << "NULL";
		cout << endl;
	}

	//2. retrieve names into the table using hashing
	cout << endl;
	key = "grape";
	cout << "Retrieve \"" << key << "\" from index " << simpleHash(key, table.size()) << endl;
 
}


