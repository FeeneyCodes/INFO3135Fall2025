// Project Help Demo.cpp : this is a small demo for implementing a decision tree
//

#include <iostream>

//This is a class that will hold all the parameter that the decision is based on
class Params
{
public:
    int age;
    bool does_exercise;
    bool eats_healthy;

    Params() :age(0),does_exercise(false),eats_healthy(false){}
};
 //These are the decision
//the logic will be passed in via a function pointer
//this allows us to re use this structure without caring what the nodes logic is

class Node
{
public:
    using processing_function_type = bool(*)(Node* node, const Params& params);
    processing_function_type internal_processing_function;
    Node* true_child;
    Node* false_child;

    Node(const processing_function_type processing_function,Node* true_node=nullptr,Node* false_node=nullptr):internal_processing_function(processing_function),true_child(true_node),false_child(false_node){}

    //calls the logic funxtions for the node
    bool process(const Params& params)
    {
        return internal_processing_function(this, params);
    }

};
 
//implement function for Node logix

//internal logic
bool eats_healthy(Node* node, const Params& params)
{
    if (params.eats_healthy)
    {
        return node->true_child->process(params);
    }
    return node->false_child->process(params);

}

bool does_exercise(Node* node, const Params& params)
{
    if (params.does_exercise)
    {
        return node->true_child->process(params);
    }
    return node->false_child->process(params);

}

//root logic

bool age_ST30(Node* node, const Params& params)
{
    if (params.age<30)
    {
        return node->true_child->process(params);
    }
    return node->false_child->process(params);

}

//terminal nodes logic(notice it is just a return value
bool fit(Node* node, const Params& params)
{
    return true;

}

bool un_fit(Node* node, const Params& params)
{
    return false;

}

Node* buildTree()
{
    //create the tree from buttom level up

    //Leave node
    Node* fit_node = new Node(fit);
    Node* unfit_node = new Node(un_fit);

    //internal nodes
    //the rest nodes just contains the decisiion logics
    Node* eats_healthy_node = new Node(eats_healthy, fit_node, unfit_node);
    Node* does_exercise_node = new Node(does_exercise, fit_node, unfit_node);


    //root node
    Node* is_fit = new Node(age_ST30, eats_healthy_node, does_exercise_node);

    //return root node
    return is_fit;


}


int main()
{
    //setup the params
    Params params;
    params.age = 29;
    params.does_exercise = true;
    params.eats_healthy = false;

    //use the decision tree

    const bool result = buildTree()->process(params);

    std::cout << "Is Fit: " << (result ? "Yes" : "No");







   
}
