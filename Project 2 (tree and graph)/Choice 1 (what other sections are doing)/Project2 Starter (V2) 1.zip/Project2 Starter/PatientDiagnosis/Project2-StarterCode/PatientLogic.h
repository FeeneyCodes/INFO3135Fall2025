/**	file PatientLogic.h
	author :
	date :
	purpose: Defines the Patient sturct and specifies the logic that the tree will use
*/
#pragma once
#include <iostream>
class PatientLogic {
public:
	//patient class to create an object to examine
	struct patient
	{
		
	};

	//Setting up the logic function for each node



};